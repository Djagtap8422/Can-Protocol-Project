//adc.h
// adc.h
#ifndef _ADC_H_
#define _ADC_H_

#include "types.h"

// Function Prototypes
void Init_ADC(void);
f32 Read_ADC(u8 chNo);

#endif

/*
#ifndef _ADC_H_
#define _ADC_H_

#include "types.h"
void Init_ADC(void);
f32 Read_ADC(u8 chNo);

#endif
*/
